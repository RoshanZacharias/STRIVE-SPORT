from django.shortcuts import render,redirect, get_object_or_404
from django.contrib.auth import authenticate,login, get_user_model, logout
from django.contrib import messages
from django.http import HttpResponse
import random
from django_otp import user_has_device, devices_for_user
from .models import OTP, UserProfile
from django.core.mail import send_mail
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from adminpanel.models import Product, Category
from user.models import Cart, CartItem
from django.core.exceptions import ObjectDoesNotExist


# Create your views here.

def index(request):
    products = Product.objects.all()
    category = Category.objects.all()

    context = {
        'products': products,
        'user': request.user,
        'category': category
    }
    return render(request, 'user_side/index.html', context)


def generate_otp():
    #generate a random otp of 6 digits
    return str(random.randint(100000, 999999))


def login_with_email_and_otp(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        print('*******************',email,password)
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # If the user has already set up an OTP device (TOTP)
            # Generate OTP
            otp_value = generate_otp()

            # Save the OTP to the database
            otp = OTP.objects.create(user=user)
            otp.otp = otp_value
            otp.save()

            # Send the OTP to the user's email
            send_otp_email(email, otp_value)
            print('*******************',email,password)

            # Prepare the context for OTP verification view
            context = {'user': user, 'is_login': True}
            return redirect('verify_otp_login', email=email)
        else:
            return render(request, 'user_side/login.html', {'error': 'Invalid email or password.'})

    return render(request, 'user_side/login.html')





def send_otp_email(email, otp_value):
    subject = 'OTP Verification'
    message = f'Your OTP for verification is: {otp_value}'
    from_email = 'roshanzacharias20@gmail.com'  # Replace with your email address
    recipient_list = [email]

    # Use the Django send_mail function to send the OTP
    send_mail(subject, message, from_email, recipient_list)



def verify_otp(request, email):
    if request.method == 'POST':
        otp_value = request.POST.get('otp')

        try:
            user = get_user_model().objects.get(email=email)
        except get_user_model().DoesNotExist:
            messages.error(request, 'Invalid user ID.')
            return render(request, 'user_side/login.html')

        otp = OTP.objects.filter(user=user, otp=otp_value).first()
        if otp:
            # Validate the OTP and log in the user
            otp.delete()  # Remove the used OTP from the database
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            messages.success(request, 'Login successful!')
            return redirect('login_with_email_and_otp')  # Replace 'home' with the name of your home page URL
        else:
            messages.error(request, 'Invalid OTP.')

    return render(request, 'user_side/verify_otp.html', {'email': email})



def verify_otp_login(request, email):
    if request.method == 'POST':
        otp_value = request.POST.get('otp')

        try:
            user = get_user_model().objects.get(email=email)
        except get_user_model().DoesNotExist:
            messages.error(request, 'Invalid email.')
            return redirect('login')

        otp = OTP.objects.filter(user=user, otp=otp_value).first()
        if otp:
            # Validate the OTP and log in the user
            otp.delete()  # Remove the used OTP from the database
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            messages.success(request, 'Login successful!')
            return redirect('index')  # Replace 'index.html' with your home page URL
        else:
            messages.error(request, 'Invalid OTP.')

    return render(request, 'user_side/verify_otp_login.html', {'email': email})



def logout_view(request):
    logout(request)
    return redirect('index')






def register_user(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        name = request.POST.get('name')
        mobile = request.POST.get('mobile')
        confirm_password = request.POST.get('confirm_password')

        # Check if the email is already registered
        if UserProfile.objects.filter(email=email).exists():
            return render(request, 'user_side/user_signup.html', {'error': 'Email already registered.'})

        # Check if the passwords match
        if password != confirm_password:
            return render(request, 'user_side/user_signup.html', {'error': 'Passwords does not match.'})

        # Create a new User instance and save it to the database
        user = User.objects.create_user(email, email=email, password=password)
        user.save()
        
        # Create a new UserProfile instance and save it to the database
        user_profile = UserProfile.objects.create(user=user,email=email, name=name, mobile=mobile)

        # Generate OTP and save it to the database
        otp_value = generate_otp()
        otp = OTP.objects.create(user=user)
        otp.otp = otp_value
        otp.save()

        # Send the OTP to the user's email
        send_otp_email(email, otp_value)

        # Prepare the context for OTP verification view
        context = {'user': user_profile.user, 'is_login': False}
        return redirect('verify_otp', email=email)

    return render(request, 'user_side/user_signup.html')

    

def product_detail(request, product_id):
    products = get_object_or_404(Product, pk=product_id)
    in_cart = CartItem.objects.filter(cart__cart_id= _cart_id(request), product=products).exists()
    context = {
        'products': products,
        'in_cart': in_cart,
    }
    return render(request, 'user_side/product-detail.html', context)



def _cart_id(request):
    cart = request.session.session_key
    if not cart:
        cart = request.session.create()
    return cart


def add_cart(request, product_id):
    product = Product.objects.get(product_id=product_id)   #get the product_id
    try:
        cart = Cart.objects.get(cart_id=_cart_id(request))  #get the cart using the cart_id present in the session
    except Cart.DoesNotExist:
        cart = Cart.objects.create(
            cart_id = _cart_id(request)
        )
    cart.save()

    try:
        cart_item = CartItem.objects.get(product=product, cart=cart)
        cart_item.quantity += 1
        cart_item.save()
    except CartItem.DoesNotExist:
        cart_item = CartItem.objects.create(
            product=product,
            quantity=1,
            cart=cart,
        )
        cart_item.save()
    return redirect('shopping_cart')


def remove_cart(request, product_id):
    cart = Cart.objects.get(cart_id=_cart_id(request))
    product = get_object_or_404(Product, product_id=product_id)
    cart_item = CartItem.objects.get(product=product, cart=cart)
    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.save()
    else:
        cart_item.delete()
    return redirect('shopping_cart')



def remove_cart_item(request, product_id):
    cart = Cart.objects.get(cart_id = _cart_id(request))
    product = get_object_or_404(Product, product_id=product_id)
    cart_item = CartItem.objects.get(product=product, cart=cart)
    cart_item.delete()
    return redirect('shopping_cart')



def cart(request, total=0, quantity=0, cart_items=None):
    try:
        tax=0
        grand_total=0
        cart = Cart.objects.get(cart_id = _cart_id(request))
        cart_items = CartItem.objects.filter(cart=cart, is_active=True)
        for cart_item in cart_items:
            total += (cart_item.product.price * cart_item.quantity)
            quantity += cart_item.quantity
        tax = (2 * total)/100
        grand_total = total+tax
    except ObjectDoesNotExist:
        pass 

    context = {
        'total': total,
        'quantity': quantity,
        'cart_items': cart_items,
        'tax': tax,
        'grand_total': grand_total
    }

    return render(request, 'user_side/shoping-cart.html', context)


def user_profile(request):
    user_profile = UserProfile.objects.get(user=request.user)

    context = {
        'user_profile': user_profile,
    }
    return render(request, 'user_side/user_profile.html', context)


def edit_profile(request):
    user_profile = request.user.userprofile  # Get the UserProfile instance for the logged-in user

    if request.method == 'POST':
        # Handle the form submission and update the user details
        full_name = request.POST.get('full_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')

        # Update the user profile fields with the form data
        user_profile.name = full_name
        user_profile.user.username = username
        user_profile.email = email
        user_profile.mobile = mobile

        # Save the changes to the UserProfile and User models
        user_profile.save()
        user_profile.user.save()

        return redirect('user_profile')  # Redirect to the user profile page after successful update
    else:
        return render(request, 'edit_profile.html', {'user_profile': user_profile})